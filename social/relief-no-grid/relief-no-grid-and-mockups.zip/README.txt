RELIEF / CENTRED VISUALS AND PRODUCT MOCKUPS

01–06: restored single-image studies with no surrounding grid, margin frame, registration crosses or added text. Subject-level tracking boxes and motion labels retained.
07–08: studio iPhone-style device renders created in Blender Cycles. Actual instrument.png and four-loops.png app captures are screen textures mapped to rounded display geometry. No AI-generated or redrawn UI. Device geometry, glass shading, lighting and perspective rendered together. These are conceptual iPhone mockups, not photographs or official Apple assets.
All eight PNG images1080×1350. No app changes performed.
